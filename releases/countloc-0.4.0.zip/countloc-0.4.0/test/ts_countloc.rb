$:.unshift File.join(File.dirname(__FILE__), "..", "lib")

# Copyright (C) 2008  Stephen Doyle

require 'test/unit'
require 'tc_ruby'
require 'tc_python'
require 'tc_cpp'
require 'tc_vb'
