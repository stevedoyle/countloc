=begin
  This is a ruby file that uses multi-line comments.
  It is used for testing countloc
=end

puts "Hello World"
puts "Blah, blah, blah ..."
